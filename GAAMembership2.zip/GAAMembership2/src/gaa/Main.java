package gaa;

public class Main {
    public static void main(String[] args) {
        LoginWindow.main(args);
    }
}
